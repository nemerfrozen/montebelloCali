@extends('layouts.app')
@section('title', 'Buscador de clasificados')
@section('content')
   <x-jumbotron />          
   {{-- @livewire('item-search') --}}
   <livewire:item-search />
@endsection   

