<?php $__env->startSection('footer'); ?>
    <footer class="footer">
        <div class="container">
            <span class="text-muted
            ">© 2021 Montebello Cali - Clasificados</span>
        </div>
    </footer>
<?php $__env->stopSection(); ?><?php /**PATH C:\xampp\htdocs\resources\views/layouts/footer.blade.php ENDPATH**/ ?>