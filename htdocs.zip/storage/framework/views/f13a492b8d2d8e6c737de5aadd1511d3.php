<header class="bg-white shadow text-white h-16">
    <div class="py-6 flex justify-between items-center bg--header px-4">
        <!-- Logo -->
        <div class="text-lg font-bold">
            <a href="/">Montebello Cali</a>
            
        </div>
        <!-- Navigation -->
        <nav class="space-x-2">
            <a href="<?php echo e(url('/')); ?>" class="text-gray-100 hover:text-blue-500">Inicio</a>
            <a href="<?php echo e(url('/clasificado/crear')); ?>" class="text-gray-100 hover:text-blue-500">Crear Clasificado</a>
            <a href="<?php echo e(url('/contacto')); ?>" class="text-gray-100 hover:text-blue-500">Contacto</a>
        </nav>
      
    </div>
</header>
<?php /**PATH C:\xampp\htdocs\resources\views/components/header.blade.php ENDPATH**/ ?>