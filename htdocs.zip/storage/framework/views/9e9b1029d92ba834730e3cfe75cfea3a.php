
<?php $__env->startSection('title', 'Buscador de clasificados'); ?>
<?php $__env->startSection('content'); ?>
   <?php if (isset($component)) { $__componentOriginald4de849f311f841c44da5c99d89e745a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald4de849f311f841c44da5c99d89e745a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.jumbotron','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jumbotron'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald4de849f311f841c44da5c99d89e745a)): ?>
<?php $attributes = $__attributesOriginald4de849f311f841c44da5c99d89e745a; ?>
<?php unset($__attributesOriginald4de849f311f841c44da5c99d89e745a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald4de849f311f841c44da5c99d89e745a)): ?>
<?php $component = $__componentOriginald4de849f311f841c44da5c99d89e745a; ?>
<?php unset($__componentOriginald4de849f311f841c44da5c99d89e745a); ?>
<?php endif; ?>          
   
   <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('item-search', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-550316952-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
<?php $__env->stopSection(); ?>   


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resources\views/classifieds/index.blade.php ENDPATH**/ ?>