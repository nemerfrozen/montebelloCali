<?php $__env->startSection('content'); ?>
    <h1>Create Listing</h1>
    <form method="POST" action="<?php echo e(route('classifieds.store')); ?>" enctype="multipart/form-data">
        <div class="form-group">
           <label for="title">Title</label>
              <input type="text" class="form-control" id="title" name="title" placeholder="Title">
        </div>
        <div class="form-group">
           <label for="short_description">Short Description</label>
              <input type="text" class="form-control" id="short_description" name="short_description" placeholder="Short Description">
        </div>
        <div class="form-group">
           <label for="description">Description</label>
              <textarea class="form-control" id="description" name="description" placeholder="Description"></textarea>
        </div>
        <div class="form-group">
           <label for="price">Price</label>
              <input type="text" class="form-control" id="price" name="price" placeholder="Price">
        </div>
        <div class="form-group">
           <label for="category">Category</label>
              <input type="text" class="form-control" id="category" name="category" placeholder="Category">
        </div>
        <div class="form-group">
           <label for="location">Location</label>
              <input type="text" class="form-control" id="location" name="location" placeholder="Location">
        </div>
        <div class="form-group">
           <label for="phone">Phone</label>
              <input type="text" class="form-control" id="phone" name="phone" placeholder="Phone">
        </div>
        <div class="form-group">
           <label for="image">Image</label>
              <input type="file" class="form-control" id="image" name="image">
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
        <?php echo csrf_field(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u239700068/domains/montebellocali.com/public_html/resources/views/classifieds/create.blade.php ENDPATH**/ ?>